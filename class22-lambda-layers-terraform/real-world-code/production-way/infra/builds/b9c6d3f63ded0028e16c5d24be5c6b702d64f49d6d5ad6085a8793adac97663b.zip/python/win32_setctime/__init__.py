from ._setctime import setctime, SUPPORTED

__version__ = "1.2.0"
__all__ = ["setctime", "SUPPORTED"]
